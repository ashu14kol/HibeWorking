package com.demo;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class Demo {
	public static void main(String[] args) {
		Student s1 = new Student(1, "Ashu", "kalyan");
		Student s2 = new Student(2, "kkk", "uu");
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			session.save(s1);
			session.save(s2);
			transaction.commit();
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}
}
